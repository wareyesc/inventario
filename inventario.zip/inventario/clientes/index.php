<?php


//Quemamos el cliente ya que no tenemos sesiones implementadas actualmente.
$id_cliente = 1;
$stateForm = 0;
$message = "";



//Conectar a la DB
require '../admon/databases.php';
//Validaciones de campos
if (!empty($_POST)) {


    if (isset($_POST["submit"])) {

        $stateForm = 1;
        $id_productoError = null;
        $cant_productoError = null;


        // keep track post values
        $id_producto = $_POST['id_producto'];
        $cant_producto = $_POST['cant_producto'];


        // validate input
        $valid = true;
        if (empty($id_producto)) {
            $id_productoError = 'Por favor complete el producto.';
            $valid = false;
        }

        if (empty($cant_producto)) {
            $cant_productoError = 'Por favor registre la cantidad del producto.';
            $valid = false;
        }

        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "SELECT cantidad FROM producto where id_producto = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($id_producto));
            $data = $q->fetch(PDO::FETCH_ASSOC);
            $cantidadTotal = $data['cantidad'];
            if($cantidadTotal != 0){
            if($cantidadTotal >= $cant_producto ){
                //Validamos que existan suficientes productos y actualizamos la cantidad.
                $nuevaCantidad = $cantidadTotal - $cant_producto;
                $sql2 = "UPDATE producto SET cantidad = ? WHERE id_producto= ? ";
                $q2 = $pdo->prepare($sql2);
                $q2->execute(array($nuevaCantidad, $id_producto));
                //Calculamos el costo de la venta antes de restrar la compra.
                $sql3 = "SELECT valor_und FROM producto where id_producto = ?";
                $q3 = $pdo->prepare($sql3);
                $q3->execute(array($id_producto));
                $data = $q3->fetch(PDO::FETCH_ASSOC);
                $valor_unidad = $data['valor_und'];            
                $costoTotal = $valor_unidad * $cant_producto;
                //Agregamos la venta.
                $sql4 = "INSERT INTO ventas (id_cliente, id_producto, cant_producto, precio_total ) values(?, ?, ?, ?)";
                $q4 = $pdo->prepare($sql4);
                $q4->execute(array($id_cliente, $id_producto, $cant_producto, $costoTotal));
                Database::disconnect();
            }else{
                $valid = false;
                $message2 = "Cantidad en stock insuficiente. Ingrese una cantidad inferior a $cantidadTotal unidades.";
            }
            }else{
                $valid = false;
                $message2 = "Lo sentimos. Actualmente no hay productos disponibles en stock.";
            }
            
            //header("Location: index.php");
        }

        if ($valid != true) {
            $message = "La compra no se ha completado correctamente.";
        } else {
            $message = "La compra se ha registrado correctamente.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/js/tempusdominus-bootstrap-4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/css/tempusdominus-bootstrap-4.min.css" />
</head>

<body>
    <div class="container">


        <div class="pt-5">
            <div class="row card text-white text-center bg-secondary mb-3 pt-4 pb-4">
                <h3>Comprar producto.</h3>

            </div>

            <?php

            if ($stateForm != 0) {
                if ($valid == false) { ?>
                    <script>
                        $(document).ready(function() {
                            $("#myModal").modal("show");
                        });
                    </script>

                    <!-- Modal -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="alert alert-danger" role="alert">
                                        <center><strong><?php echo $message; ?><br><br><?php echo $message2; ?></strong><center>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <a href="index.php" class="btn btn-dark">Cerrar</a> </div>
                            </div>
                        </div>
                    </div>

                <?php } else { ?>
                    <script>
                        $(document).ready(function() {
                            $("#myModal").modal("show");
                        });
                    </script>

                    <!-- Modal -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="alert alert-success" role="alert">
                                        <center><strong><?php echo $message; ?><br><br></strong></center>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <a href="index.php" class="btn btn-dark">Cerrar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>


            <form class="card" action="index.php" method="post" enctype="multipart/form-data">
                <div class="card-body">
                    <h5 for="exampleFormControlSelect1">Seleccione producto</h5>
                    <select class="form-control" id="exampleFormControlSelect1" name="id_producto" required>
                        <?php
                        $pdo = Database::connect();
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        $sql = "SELECT * FROM producto";
                        $stmt = $pdo->prepare($sql);
                        $result = $stmt->execute();
                        $rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
                        foreach ($rows as $row) {
                            ?>
                            <option value="<?php print($row->id_producto); ?>"><?php print($row->nombre); ?></option>
                        <?php
                    }
                    ?>
                    </select>
                </div>

                <div class="card-body">
                    <h5 class="card-title">Seleccione la cantidad</h5>
                    <div class="controls">
                        <input class="form-control form-control-lg" name="cant_producto" type="number" min="1" max="10000000" rows="2" placeholder="Por favor escriba la cantidad." required></input>
                        <?php if (!empty($cant_productoError)) : ?>
                            <div class="alert alert-warning" role="alert">
                                <?php echo $cant_productoError; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card-body pt-4 text-center">
                    <button type="submit" class="btn btn-warning" name="submit" enctype="multipart/form-data">Comprar</button>
                    <a href="index.php"><button type="button" class="btn btn-info">Volver</button></a>
                </div>
            </form>
        </div>

    </div> <!-- /container -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>