<?php

//Traer fecha de hoy
setlocale(LC_TIME, 'es_ES.UTF-8');
date_default_timezone_set('America/Lima');
$fechaHoy = date('d-m-Y H:i:s');
//Quemamos el proveedor ya que tenemos sesiones activas.
$proveedor = 1;
$stateForm = 0;
$message = "";



//Conectar a la DB
require '../admon/databases.php';
//Validaciones de campos
if (!empty($_POST)) {


    if (isset($_POST["submit"])) {

        $stateForm = 1;
        $id_productoError = null;
        $cant_entregaError = null;
        $num_loteError = null;
        $fecha_venError = null;
        $precioError = null;

        // keep track post values
        $id_producto = $_POST['id_producto'];
        $cant_entrega = $_POST['cant_entrega'];
        $num_lote = $_POST['num_lote'];
        $fecha_ven = $_POST['fecha_ven'];
        $id_proveedor = $_POST['id_proveedor'];
        $precio = $_POST['precio'];


        // validate input
        $valid = true;
        if (empty($id_producto)) {
            $id_productoError = 'Por favor complete el producto.';
            $valid = false;
        }

        if (empty($cant_entrega)) {
            $cant_entregaError = 'Por favor registre la cantidad del producto.';
            $valid = false;
        }

        if (empty($num_lote)) {
            $num_loteError = 'Por favor ingrese el # de lote.';
            $valid = false;
        }
        if (empty($fecha_ven)) {
            $fecha_venError = 'Por favor ingrese la fecha de vencimiento.';
            $valid = false;
        }
        if (empty($precio)) {
            $precioError = 'Por favor ingrese el precio del producto.';
            $valid = false;
        }

        // insert data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO entregas (id_producto,cant_entrega,num_lote,fecha_ven,fecha_reg,id_proveedor,precio) values(?, ?, ?, ?, ?, ?, ?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($id_producto, $cant_entrega, $num_lote, $fecha_ven, $fechaHoy, $id_proveedor, $precio));
            $sql2_1 = "SELECT cantidad FROM producto where id_producto = ?";
            $q2_1 = $pdo->prepare($sql2_1);            
            $q2_1->execute(array($id_producto));
            $data2 = $q2_1->fetch(PDO::FETCH_ASSOC);
            $dataCantidad = $data2['cantidad'];
            $sumaTotal = $dataCantidad + $cant_entrega;
            $sql3 = "UPDATE producto SET cantidad = ? WHERE id_producto= ? ";
            $q3 = $pdo->prepare($sql3);
            $q3->execute(array($sumaTotal, $id_producto));
            Database::disconnect();
            //header("Location: index.php");
        } else { }

        if ($valid != true) {
            $message = "No se ha realizado el registro del producto.";
        } else {
            $message = "El producto se ha registrado correctamente.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/js/tempusdominus-bootstrap-4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/css/tempusdominus-bootstrap-4.min.css" />
</head>

<body>
    <div class="container">

        <div class="pt-5">
            <div class="row card text-white text-center bg-secondary mb-3 pt-4 pb-4">
                <h3>Entregar producto.</h3>
            </div>

            <?php

            if ($stateForm != 0) {
                if ($valid == false) { ?>
                    <script>
                        $(document).ready(function() {
                            $("#myModal").modal("show");
                        });
                    </script>

                    <!-- Modal -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="alert alert-danger" role="alert">
                                        <strong><?php echo $message; ?><br></strong>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <a href="index.php" class="btn btn-dark">Cerrar</a> </div>
                            </div>
                        </div>
                    </div>

                <?php } else { ?>
                    <script>
                        $(document).ready(function() {
                            $("#myModal").modal("show");
                        });
                    </script>

                    <!-- Modal -->
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="alert alert-success" role="alert">
                                        <strong><?php echo $message; ?><br></strong>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <a href="index.php" class="btn btn-dark">Cerrar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>


            <form class="card" action="index.php" method="post" enctype="multipart/form-data">
                <div class="card-body">
                    <h5 for="exampleFormControlSelect1">Seleccione producto</h5>
                    <select class="form-control" id="exampleFormControlSelect1" name="id_producto" required>
                        <?php
                        $pdo = Database::connect();
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        $sql5 = "SELECT * FROM producto";
                        $stmt = $pdo->prepare($sql5);
                        $result = $stmt->execute();
                        $rows = $stmt->fetchAll(\PDO::FETCH_OBJ);
                        foreach ($rows as $row) {
                            ?>
                            <option value="<?php print($row->id_producto); ?>"><?php print($row->nombre); ?></option>
                        <?php
                    }
                    ?>
                    </select>
                </div>

                <div class="card-body">
                    <h5 class="card-title">Seleccione la cantidad</h5>
                    <div class="controls">
                        <input class="form-control form-control-lg" name="cant_entrega" type="number" min="1" max="10000000" rows="2" placeholder="Por favor escriba la cantidad." required></input>
                        <?php if (!empty($cant_entregaError)) : ?>
                            <div class="alert alert-warning" role="alert">
                                <?php echo $cant_entregaError; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <h5 class="card-title">Número de Lote.</h5>
                    <div class="controls">
                        <input class="form-control form-control-lg" name="num_lote" type="number" min="5" placeholder="Por favor escriba el número de lote." required></input>
                        <?php if (!empty($num_loteError)) : ?>
                            <div class="alert alert-warning" role="alert">
                                <?php echo $num_loteError; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body <?php echo !empty($fecha_ven) ? 'error' : ''; ?>">
                    <h5 class="card-title">Fecha de vencimiento</h5>
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <div class="input-group date" id="datetimepicker4" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" data-target="#datetimepicker4" name="fecha_ven"/>
                                        <div class="input-group-append" data-target="#datetimepicker4" data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script type="text/javascript">
                                $(function() {
                                    $('#datetimepicker4').datetimepicker({
                                        format: 'L'
                                    });
                                });
                            </script>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <h5 class="card-title">Precio</h5>
                    <div class="controls">
                        <input class="form-control form-control-lg" name="precio" type="number" min="1" max="10000000" placeholder="Por favor escriba el precio de los productos agregados." required></input>
                        <?php if (!empty($precioError)) : ?>
                            <div class="alert alert-warning" role="alert">
                                <?php echo $precioError; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="controls">
                        <textarea style="display:none" name="fecha_reg" type="text" rows="2" value="<?php print($fechaHoy); ?>"><?php echo $fechaHoy; ?></textarea>
                    </div>
                </div>
                <div class="card-body">
                    <div class="controls">
                        <textarea style="display:none" name="id_proveedor" type="text" rows="2" value="<?php print($row->id_proveedor); ?>"><?php echo $proveedor; ?></textarea>
                    </div>
                </div>

                <div class="card-body pt-4 text-center">
                    <button type="submit" class="btn btn-success" name="submit" enctype="multipart/form-data">Crear</button>
                    <a href="index.php"><button type="button" class="btn btn-info">Volver</button></a>
                </div>
            </form>
        </div>

    </div> <!-- /container -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>