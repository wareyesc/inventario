<?php

require 'databases.php';
$id = 0;

if (!empty($_GET['id'])) {
    $id = $_REQUEST['id'];
}

if (!empty($_POST)) {
    // keep track post values
    $id = $_POST['id'];

    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT cant_producto, id_producto FROM ventas where id_venta = ?";
    $q = $pdo->prepare($sql);
    $q->execute(array($id));
    $data = $q->fetch(PDO::FETCH_ASSOC);
    $cantProducto = $data['cant_producto'];
    echo $cantProducto;
    $idProducto = $data['id_producto'];
    $sql2_1 = "SELECT cantidad FROM producto where id_producto = ?";
    $q2_1 = $pdo->prepare($sql2_1);
    $q2_1->execute(array($idProducto));
    $data2 = $q2_1->fetch(PDO::FETCH_ASSOC);
    $cantidadProducto = $data2['cantidad'];
    $sumaTotal = $cantidadProducto + $cantProducto;
    $sql2 = "UPDATE producto SET cantidad = ? WHERE id_producto= ? ";
    $q2 = $pdo->prepare($sql2);
    $q2->execute(array($sumaTotal, $idProducto));
    $sql3 = "DELETE FROM ventas  WHERE id_venta= ?";
    $q3 = $pdo->prepare($sql3);
    $q3->execute(array($id));
    Database::disconnect();
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">


<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://raw.githubusercontent.com/frexy/svg-icon-webcomponent/master/build/iconwc.js">

    <!-- https://www.w3schools.com/icons/icons_reference.asp -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <title>Dashboard Inventario</title>

</head>

<body>
    <div class="container">

        <div class="pt-5">
            <div class="row card text-white text-center bg-info mb-3 pt-4">
                <h3>Cancelar Factura</h3>
            </div>

            <form class="form-group" action="cancelar.php" method="post">
                <input type="hidden" name="id" value="<?php echo $id; ?>" />
                <p class="alert alert-danger" role="alert">¿ Esta seguro que desea eliminar la factura N°: <?php echo $id; ?> ?</p>
                <div class="card-body">
                    <button type="submit" class="btn btn-danger">Si</button>
                    <a class="btn btn-dark" href="inventario.php">No</a>
                </div>
            </form>
        </div>

    </div> <!-- /container -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



</body>

</html>