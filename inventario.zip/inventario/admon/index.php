<?php
// include("cache.php");
// session_start(['cookie_lifetime' => 1200,]);
// if ($_SESSION["email"] == NULL) {
//   header('Location: ../login.php'); //take user to the login page if there's no information stored in session variable
//}
?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://raw.githubusercontent.com/frexy/svg-icon-webcomponent/master/build/iconwc.js">

  <!-- https://www.w3schools.com/icons/icons_reference.asp -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <title>Dashboard Inventario</title>

<body>

  <!-- Menú -->

  <div class="pos-f-t">
    <div class="collapse" id="navbarToggleExternalContent">
      <div class="bg-dark p-4">
        <div class="row justify-content-end pr-5 pt-1">
          <i class="material-icons" style="font-size:60px; color:white;">person_pin</i>
          <a style="color:white;"></a>
        </div>
        <div class="row justify-content-end pr-5 pt-5">
          <a href='../logout.php'><button type="button" class="btn btn-danger align-self-end">Salir</button></a>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-dark bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
  </div>
  <!-- Fin Menú -->

  <div class="container">
    <div class="row pt-5 justify-content-center">
      <h3>Dashboard Inventario</h3>
    </div>
    <div class="row pt-1 justify-content-center">
      <h4 class="card-subtitle mb-2 text-muted">Bienvenido</h4>
    </div>
    <div class="row pt-5">

      <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Lote de Proveedores</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Inventario</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Facturación</a>
        </li>
      </ul>
      <div class="container-fluid">
        <div class="tab-content content-fluid" id="pills-tabContent">
          <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">



            <table class="table table-sm table-hover table-striped table-bordered">
              <thead class="thead-dark">
                <tr>
                  <th class="text-center" scope="col">Id Producto</th>
                  <th class="text-center" scope="col">Producto</th>
                  <th class="text-center" scope="col">Cantidad</th>
                  <th class="text-center" scope="col">Lote</th>
                  <th class="text-center" scope="col">F. Vencimiento</th>
                  <th class="text-center" scope="col">F. Registro</th>
                  <th class="text-center" scope="col">Proveedor</th>
                  <th class="text-center" scope="col">Costo</th>

                </tr>
              </thead>
              <tbody>
                <?php
                include 'databases.php';
                $pdo = Database::connect();
                $pdo3 = Database::connect();                
                $pdo2 = Database::connect();

                $sql = 'SELECT entregas.id_producto, producto.nombre, entregas.cant_entrega, entregas.num_lote, entregas.fecha_ven, entregas.fecha_reg, proveedor.proveedor, entregas.precio FROM entregas INNER JOIN proveedor ON entregas.id_proveedor = proveedor.id_proveedor INNER JOIN producto ON entregas.id_producto = producto.id_producto ORDER BY id_producto';
                $sql3 = 'SELECT producto.id_producto, producto.nombre, producto.descripcion, producto.valor_und, producto.cantidad FROM producto ORDER BY id_producto';
                $sql2 = 'SELECT ventas.id_venta, cliente.cliente, producto.nombre, ventas.cant_producto, ventas.precio_total, ventas.id_producto FROM ventas INNER JOIN cliente ON ventas.id_cliente = cliente.id_cliente INNER JOIN producto ON ventas.id_producto = producto.id_producto ORDER BY id_venta';
                foreach ($pdo->query($sql) as $row) {
                  echo '<tr>';
                  echo '<td class="text-center" width="60px">' . $row['id_producto'] . '</td>';
                  echo '<td class="text-center" width="180px">' . $row['nombre'] . '</td>';
                  echo '<td class="text-center" width="40px">' . $row['cant_entrega'] . '</td>';
                  echo '<td class="text-center">' . $row['num_lote'] . '</td>';
                  echo '<td class="text-center">' . $row['fecha_ven'] . '</td>';
                  echo '<td class="text-center">' . $row['fecha_reg'] . '</td>';
                  echo '<td class="text-center">' . $row['proveedor'] . '</td>';
                  echo '<td class="text-center">' . $row['precio'] . '</td>';
                }
                ?>
              </tbody>
            </table>

          </div>
          <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">


          <table class="table table-sm table-hover table-striped table-bordered">
              <thead class="thead-dark">
                <tr>
                  <th class="text-center" scope="col">Id Producto</th>
                  <th class="text-center" scope="col">Nombre</th>
                  <th class="text-center" scope="col">Descripción</th>
                  <th class="text-center" scope="col">Valor Unidad</th>
                  <th class="text-center" scope="col">Cantidad</th>


                </tr>
              </thead>
              <tbody>
                <?php
                foreach ($pdo3->query($sql3) as $row) {
                  echo '<tr>';
                  echo '<td class="text-center" width="60px">' . $row['id_producto'] . '</td>';
                  echo '<td class="text-center" width="240px">' . $row['nombre'] . '</td>';
                  echo '<td class="text-center">' . $row['descripcion'] . '</td>';
                  echo '<td class="text-center">' . $row['valor_und'] . '</td>';
                  echo '<td class="text-center">' . $row['cantidad'] . '</td>';
 
                }
                ?>
              </tbody>
            </table>


          </div>
          <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">

            <table class="table table-sm table-hover table-striped table-bordered">
              <thead class="thead-dark">
                <tr>
                  <th class="text-center" scope="col">Id Venta</th>
                  <th class="text-center" scope="col">Cliente</th>
                  <th class="text-center" scope="col">Producto</th>
                  <th class="text-center" scope="col">Cantidad</th>
                  <th class="text-center" scope="col">Precio Total</th>
                  <th class="text-center" scope="col">Acción</th>

                </tr>
              </thead>
              <tbody>
                <?php
                foreach ($pdo2->query($sql2) as $row) {
                  echo '<tr>';
                  echo '<td class="text-center" width="60px">' . $row['id_venta'] . '</td>';
                  echo '<td class="text-center" width="240px">' . $row['cliente'] . '</td>';
                  echo '<td class="text-center">' . $row['nombre'] . '</td>';
                  echo '<td class="text-center">' . $row['cant_producto'] . '</td>';
                  echo '<td class="text-center">' . $row['precio_total'] . '</td>';
                  echo '<td class="text-center" width="350px" align="center">';
                  echo '<a class="btn btn-primary" href="factura.php?id=' . $row['id_venta'] . '">Generar Factura</a>';
                  echo ' ';
                  echo '<a class="btn btn-warning" href="cancelar.php?id=' . $row['id_venta'] . '">Cancelar Compra</a>';
                  echo '</td>';
                }
                Database::disconnect();
                ?>
              </tbody>
            </table>

          </div>
        </div>
      </div>



    </div>
  </div> <!-- /container -->

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


</body>

</html>