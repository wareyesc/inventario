<?php
// No se han implementado sesiones en este proyecto, pero se espera hacerlo.
unset($_SESSION['email']);
session_unset(); 
header('Location: index.php');
session_destroy(); 
?>