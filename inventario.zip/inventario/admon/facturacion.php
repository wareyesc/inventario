<?php
// include("cache.php");
// session_start(['cookie_lifetime' => 1200,]);
// if ($_SESSION["email"] == NULL) {
//   header('Location: ../login.php'); //take user to the login page if there's no information stored in session variable
//}
?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://raw.githubusercontent.com/frexy/svg-icon-webcomponent/master/build/iconwc.js">

  <!-- https://www.w3schools.com/icons/icons_reference.asp -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <title>Dashboard Inventario</title>

<body>

  <!-- Menú -->

  <div class="pos-f-t">
    <div class="collapse" id="navbarToggleExternalContent">
      <div class="bg-dark p-4">
        <div class="row justify-content-end pr-5 pt-1">
          <i class="material-icons" style="font-size:60px; color:white;">person_pin</i>
          <a style="color:white;"><?php echo $_SESSION["email"]; ?></a>
        </div>
        <div class="row justify-content-end pr-5 pt-5">
          <a href='../logout.php'><button type="button" class="btn btn-danger align-self-end">Salir</button></a>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-dark bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
  </div>
  <!-- Fin Menú -->

  <div class="container">
    <div class="row pt-5 justify-content-center">
      <h3>Dashboard Inventario</h3>
    </div>
    <div class="row pt-1 justify-content-center">
      <h4 class="card-subtitle mb-2 text-muted" >Lote de proveedores</h4>
    </div>

    <div class="row pt-5">
      <p>
        <a href="inventario.php" class="btn btn-success">Actualizar</a>
      </p>
      <table class="table table-sm table-hover table-striped table-bordered">
        <thead class="thead-dark">
          <tr>
            <th class="text-center" scope="col">Id Producto</th>
            <th class="text-center" scope="col">Cantidad</th>
            <th class="text-center" scope="col">Lote</th>
            <th class="text-center" scope="col">F. Vencimiento</th>
            <th class="text-center" scope="col">F. Registro</th>
            <th class="text-center" scope="col">Proveedor</th>
            <th class="text-center" scope="col">Costo</th>
            <th class="text-center" scope="col">Acción</th>

          </tr>
        </thead>
        <tbody>
          <?php
          include 'databases.php';
          $pdo = Database::connect();
          $sql = 'SELECT entregas.id_producto, entregas.cant_entrega, entregas.num_lote, entregas.fecha_ven, entregas.fecha_reg, proveedor.proveedor, entregas.precio FROM entregas INNER JOIN proveedor ON entregas.id_proveedor = proveedor.id_proveedor ORDER BY id_producto';
          foreach ($pdo->query($sql) as $row) {
            echo '<tr>';
            echo '<td class="text-center" width="60px">' . $row['id_producto'] . '</td>';
            echo '<td class="text-center" width="40px">' . $row['cant_entrega'] . '</td>';
            echo '<td class="text-center">' . $row['num_lote'] . '</td>';
            echo '<td class="text-center">' . $row['fecha_ven'] . '</td>';
            echo '<td class="text-center">' . $row['fecha_reg'] . '</td>';
            echo '<td class="text-center">' . $row['proveedor'] . '</td>';
            echo '<td class="text-center">' . $row['precio'] . '</td>';
            echo '<td class="text-center" width="350px" align="center">';
            echo '<a class="btn btn-primary" href="read.php?id=' . $row['id_producto'] . '">Generar Factura</a>';
            echo ' ';
            echo '<a class="btn btn-warning" href="delete.php?id=' . $row['id_producto'] . '">Cancelar Compra</a>';
            echo '</td>';
          }
          Database::disconnect();
          ?>
        </tbody>
      </table>
    </div>
  </div> <!-- /container -->

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


</body>

</html>