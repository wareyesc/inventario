<?php
require 'databases.php';
$id = null;
if (!empty($_GET['id'])) {
  $id = $_REQUEST['id'];
}

if (null == $id) {
  header("Location: index.php");
} else {
  $pdo = Database::connect();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "SELECT ventas.id_cliente, ventas.cant_producto, ventas.precio_total, cliente.cliente, producto.nombre, ventas.id_producto FROM ventas INNER JOIN cliente ON ventas.id_cliente = cliente.id_cliente INNER JOIN producto ON ventas.id_producto = producto.id_producto where id_venta = ?";
  $q = $pdo->prepare($sql);
  $q->execute(array($id));
  $data = $q->fetch(PDO::FETCH_ASSOC);
  Database::disconnect();
}
?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://raw.githubusercontent.com/frexy/svg-icon-webcomponent/master/build/iconwc.js">

  <!-- https://www.w3schools.com/icons/icons_reference.asp -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <title>Factura Electrónica</title>

<body>

  <!-- Menú -->

  <div class="pos-f-t">
    <div class="collapse" id="navbarToggleExternalContent">
      <div class="bg-dark p-4">
        <div class="row justify-content-end pr-5 pt-1">
          <i class="material-icons" style="font-size:60px; color:white;">person_pin</i>
          <a style="color:white;"></a>
        </div>
        <div class="row justify-content-end pr-5 pt-5">
          <a href='logout.php'><button type="button" class="btn btn-danger align-self-end">Salir</button></a>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-dark bg-dark">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </nav>
  </div>
  <!-- Fin Menú -->

  <div class="container">
    <div class="row pt-5 justify-content-center">
      <h3>Dashboard Facturación</h3>
    </div>
    <div class="row pt-1 justify-content-center">
      <h4 class="card-subtitle mb-2 text-muted"></h4>
    </div>
    <div class="row justify-content-center pt-4">
      <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        <div class="row justify-content-center">
          <div class="p-3 mb-2 bg-primary text-white" style="width: 900px; height: 150px;">
            <i class="material-icons" style="font-size:60px; color:white;">check_circle_outline</i>
            <h4 class="card-subtitle mb-2 text-center">Factura de Venta</h4>
          </div>
          <div class="p-3 mb-2 bg-light" style="width: 900px; height: 600px;">
            <div class="row justify-content-center pt-4">
              <div class="col-4 col-sm-4 col-md-4 col-lg-4">
                <h4 class=" text-center">Factura Numero: <br><?php echo $id; ?></h4>
              </div>
              <div class="col-3 col-sm-3 col-md-3 col-lg-3">
                <h4 class=" text-center">Estimado(a): <br></h4>
                <?php echo $data['cliente']; ?>
              </div>
              <div class="col-3 col-sm-3 col-md-3 col-lg-3">

              </div>
            </div>
            <div class="row justify-content-center pt-5">
            <div class="col-4 col-sm-4 col-md-4 col-lg-4">
              <h4 class=" text-center">Id <br><?php echo $data['id_producto']; ?></h4>
            </div>
            <div class="col-3 col-sm-3 col-md-3 col-lg-3">
              <h4 class=" text-center">Producto: <br></h4>
              <center><?php echo $data['nombre']; ?></center>
            </div>
            <div class="col-3 col-sm-3 col-md-3 col-lg-3">
              <h4 class=" text-center">Cantidad: <br></h4>
              <center><?php echo $data['cant_producto']; ?></center>
            </div>

          </div>
          <div class="row justify-content-center pt-5">
            <div class="col-4 col-sm-4 col-md-4 col-lg-4">

            </div>
            <div class="col-3 col-sm-3 col-md-3 col-lg-3">
              <h4 class=" text-center">Total: <br></h4>
              <center><h3><?php echo $data['precio_total']; ?></h3></center>
            </div>
            <div class="col-3 col-sm-3 col-md-3 col-lg-3">

            </div>

          </div>
          </div>

        </div>
      </div>
    </div>

  </div>
  </div> <!-- /container -->

  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


</body>

</html>